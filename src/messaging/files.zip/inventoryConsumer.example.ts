import { startConsumer, publishEvent } from "../../../messaging/index.js";
import { QUEUES, ROUTING_KEYS } from "../../../shared/exchnage.js";

// This is illustrative — call registerInventoryConsumers() once at startup,
// after initMessaging() has run (so the queue already exists to consume from).

interface OrderCreatedPayload {
  orderId: string;
  items: { productId: string; quantity: number }[];
}

export async function registerInventoryConsumers(inventoryService: any) {
  await startConsumer({
    queue: QUEUES.INVENTORY_ORDER_EVENTS,
    onMessage: async (envelope, routingKey) => {
      if (routingKey !== ROUTING_KEYS.ORDER_CREATED) return;

      const { orderId, items } = envelope.payload as OrderCreatedPayload;
      const reserved = await inventoryService.reserveStock(items);

      await publishEvent(
        reserved ? ROUTING_KEYS.INVENTORY_STOCK_RESERVED : ROUTING_KEYS.INVENTORY_STOCK_FAILED,
        { orderId }
      );
    },
  });
}
