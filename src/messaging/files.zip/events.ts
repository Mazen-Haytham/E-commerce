// Every message on the bus gets wrapped in this shape, instead of publishing
// raw payloads. It costs nothing and pays off the first time you need to
// debug "why did this get processed twice" or "when was this actually sent".
export interface EventEnvelope<T = unknown> {
  eventId: string; // unique per message — use this for idempotency checks
  eventName: string; // same value as the routing key, kept for readability in logs
  occurredAt: string; // ISO timestamp of when it was published
  payload: T;
}
