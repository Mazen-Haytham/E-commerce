import { publishEvent } from "../../../messaging/index.js";
import { ROUTING_KEYS } from "../../../shared/exchnage.js";

// This is illustrative — wire it into your actual OrderService.ts.
// The point: the database write and the event publish are two separate
// steps. Orders doesn't know or care who's listening for "order.created" —
// today it's Inventory, tomorrow it might also be Notifications.

interface CreateOrderInput {
  userId: string;
  items: { productId: string; quantity: number }[];
}

export async function createOrder(data: CreateOrderInput, orderRepo: any) {
  const order = await orderRepo.create(data);

  await publishEvent(ROUTING_KEYS.ORDER_CREATED, {
    orderId: order.id,
    userId: order.userId,
    items: order.items,
  });

  return order;
}
